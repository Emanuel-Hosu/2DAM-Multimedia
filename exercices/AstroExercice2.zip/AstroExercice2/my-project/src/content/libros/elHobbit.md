---
title: El Hobbit
author: J.R.R. Tolkien
img: elHobbit.jpg
readtime: 310
description: La inesperada aventura de un hobbit que se enfrenta a dragones, tesoros y magia en su viaje hacia la Montaña Solitaria.
buy:
    spain: https://amzn.to/48JH9ZZ
    usa: https://www.amazon.com/dp/054792822X
---

*El Hobbit* narra la historia de Bilbo Bolsón, un hobbit que vive una vida tranquila en la Comarca hasta que el mago Gandalf y un grupo de trece enanos lo invitan a unirse a una misión llena de peligros y aventuras. Juntos, se embarcan en un viaje hacia la Montaña Solitaria, donde deberán recuperar el tesoro protegido por el temible dragón Smaug. En este relato precursor de *El Señor de los Anillos*, Tolkien explora la valentía y el ingenio en un mundo fantástico que ha cautivado a lectores de todas las edades.
